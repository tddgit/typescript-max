/// <reference path="utilityFunctions.ts" />
var fee = Utility.CalculateLateFee(10);
console.log("Fee: " + fee);
var maxBooks = Utility.MaxBooksAllowed(15);
console.log("Max books: " + maxBooks);
//# sourceMappingURL=ns-app.js.map