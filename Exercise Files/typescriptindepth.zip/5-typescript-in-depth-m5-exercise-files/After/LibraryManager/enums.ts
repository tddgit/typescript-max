enum Category { Biography, Poetry, Fiction, History, Children }

export { Category };