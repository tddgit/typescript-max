declare enum Category {
    Biography = 0,
    Poetry = 1,
    Fiction = 2,
    History = 3,
    Children = 4,
    Software = 5,
}
export { Category };
